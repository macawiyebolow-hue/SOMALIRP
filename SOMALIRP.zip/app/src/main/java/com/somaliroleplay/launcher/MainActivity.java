package com.somaliroleplay.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;

public class MainActivity extends Activity {

    private static final int NAVY = Color.parseColor("#050B1E");
    private static final int ORANGE = Color.parseColor("#FF8A00");
    private static final int BLUE = Color.parseColor("#1E6BFF");

    private SharedPreferences prefs;
    private MediaPlayer player;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private EditText nameBox;
    private Button mainBtn;
    private ProgressBar progress;
    private TextView status;
    private TextView playersText;
    private ImageButton settingsBtn;
    private boolean updated;
    private boolean busy;
    private volatile boolean alive = true;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("srp", MODE_PRIVATE);
        updated = prefs.getBoolean("updated", false);
        buildUi();
        startMusic();
        refreshState();
        pollPlayers();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(NAVY);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(16), dp(16), dp(16));
        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Sare: magaca akoonka (bidix) + dejinta (midig)
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        col.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        nameBox = new EditText(this);
        nameBox.setHint("Magaca Akoonka");
        nameBox.setHintTextColor(Color.parseColor("#7F93C7"));
        nameBox.setTextColor(Color.WHITE);
        nameBox.setSingleLine(true);
        nameBox.setInputType(InputType.TYPE_CLASS_TEXT);
        nameBox.setText(prefs.getString("name", ""));
        nameBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        nameBox.setBackground(rounded(Color.parseColor("#0F1B3D"), 12));
        top.addView(nameBox, new LinearLayout.LayoutParams(0, dp(46), 1f));

        settingsBtn = new ImageButton(this);
        settingsBtn.setImageResource(android.R.drawable.ic_menu_preferences);
        settingsBtn.setBackground(rounded(Color.parseColor("#0F1B3D"), 12));
        settingsBtn.setOnClickListener(v -> showSettings());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(46), dp(46));
        sp.leftMargin = dp(10);
        top.addView(settingsBtn, sp);

        // Logo
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 0, 1f);
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        lp.topMargin = dp(8);
        col.addView(logo, lp);

        // Tirada ciyaartoyda
        playersText = new TextView(this);
        playersText.setTextColor(Color.WHITE);
        playersText.setTextSize(16);
        playersText.setTypeface(Typeface.DEFAULT_BOLD);
        playersText.setGravity(Gravity.CENTER);
        col.addView(playersText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Xaalad + progress
        status = new TextView(this);
        status.setTextColor(Color.parseColor("#9FB4E8"));
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(6), 0, dp(4));
        col.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        col.addView(progress, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(8)));

        // Badhanka oranjiga ah
        mainBtn = new Button(this);
        mainBtn.setTextColor(Color.WHITE);
        mainBtn.setTextSize(20);
        mainBtn.setTypeface(Typeface.DEFAULT_BOLD);
        mainBtn.setAllCaps(true);
        mainBtn.setBackground(rounded(ORANGE, 16));
        mainBtn.setOnClickListener(v -> onMainClick());
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        mp.topMargin = dp(10);
        col.addView(mainBtn, mp);

        // Badhamada bulshada
        LinearLayout social = new LinearLayout(this);
        social.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sl.topMargin = dp(12);
        col.addView(social, sl);
        addSocial(social, "Discord", Config.DISCORD_URL);
        addSocial(social, "Instagram", Config.INSTAGRAM_URL);
        addSocial(social, "Website", Config.WEBSITE_URL);
        addSocial(social, "App", Config.APP_URL);

        setContentView(root);
    }

    private void addSocial(LinearLayout parent, String label, String url) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setAllCaps(false);
        bt.setTextSize(12);
        bt.setTextColor(Color.WHITE);
        bt.setBackground(rounded(BLUE, 12));
        bt.setPadding(0, 0, 0, 0);
        bt.setOnClickListener(v -> openLink(url));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f);
        p.leftMargin = dp(3);
        p.rightMargin = dp(3);
        parent.addView(bt, p);
    }

    private void openLink(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Linkiga lama furi karo", Toast.LENGTH_SHORT).show();
        }
    }

    // ---- Xaaladda: Cusboonaysii -> Bilow ----
    private void refreshState() {
        if (updated) {
            mainBtn.setText("BILOW");
            settingsBtn.setVisibility(View.VISIBLE);
            playersText.setVisibility(View.VISIBLE);
            status.setText("Ciyaartu way diyaar tahay");
        } else {
            mainBtn.setText("CUSBOONAYSII");
            settingsBtn.setVisibility(View.GONE);
            playersText.setVisibility(View.GONE);
            status.setText("Fadlan marka hore cusboonaysii");
        }
        mainBtn.setEnabled(!busy);
    }

    private void onMainClick() {
        if (busy) return;
        if (updated) startGame();
        else startUpdate();
    }

    private boolean checkName() {
        String n = nameBox.getText().toString().trim();
        if (n.isEmpty()) {
            Toast.makeText(this, "Fadlan geli magacaaga", Toast.LENGTH_SHORT).show();
            return false;
        }
        prefs.edit().putString("name", n).apply();
        return true;
    }

    private void startUpdate() {
        if (Config.GAME_FILES_URL.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Cusboonaysiin")
                    .setMessage("Linkiga faylasha ciyaarta weli lama dhigin. Fadlan ku dar Config.java.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        busy = true;
        mainBtn.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        progress.setProgress(0);
        status.setText("Waa la soo dejinayaa...");
        new Thread(() -> {
            boolean ok = false;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(Config.GAME_FILES_URL).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.connect();
                int total = c.getContentLength();
                File dir = getExternalFilesDir(null);
                if (dir == null) dir = getFilesDir();
                File out = new File(dir, "gamefiles.zip");
                try (InputStream in = c.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) {
                    byte[] buf = new byte[16384];
                    long done = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        fo.write(buf, 0, n);
                        done += n;
                        if (total > 0) {
                            final int pct = (int) (done * 100 / total);
                            ui.post(() -> {
                                progress.setProgress(pct);
                                status.setText("Waa la soo dejinayaa... " + pct + "%");
                            });
                        }
                    }
                }
                ok = true;
            } catch (Exception e) {
                ok = false;
            }
            final boolean success = ok;
            ui.post(() -> {
                busy = false;
                progress.setVisibility(View.GONE);
                if (success) {
                    updated = true;
                    prefs.edit().putBoolean("updated", true).apply();
                } else {
                    Toast.makeText(this, "Cusboonaysiintu way fashilantay. Isku day mar kale.",
                            Toast.LENGTH_LONG).show();
                }
                refreshState();
            });
        }).start();
    }

    private void startGame() {
        if (!checkName()) return;
        Intent i = getPackageManager().getLaunchIntentForPackage(Config.GAME_PACKAGE);
        if (i == null) {
            Toast.makeText(this, "Ciyaarta lama helin taleefankaaga", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(i);
    }

    // ---- Dejinta ----
    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), dp(0));

        CheckBox music = new CheckBox(this);
        music.setText("Muusiga");
        music.setChecked(prefs.getBoolean("music", true));
        music.setOnCheckedChangeListener((v, on) -> {
            prefs.edit().putBoolean("music", on).apply();
            if (player != null) {
                if (on) player.start();
                else if (player.isPlaying()) player.pause();
            }
        });
        box.addView(music);

        Button re = new Button(this);
        re.setText("Cusboonaysii mar kale");
        re.setOnClickListener(v -> {
            updated = false;
            prefs.edit().putBoolean("updated", false).apply();
            refreshState();
        });
        box.addView(re);

        new AlertDialog.Builder(this)
                .setTitle("Dejinta")
                .setView(box)
                .setPositiveButton("OK", null)
                .show();
    }

    // ---- Muusiga ----
    private void startMusic() {
        try {
            player = MediaPlayer.create(this, R.raw.music);
            if (player != null) {
                player.setLooping(true);
                if (prefs.getBoolean("music", true)) player.start();
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null && player.isPlaying()) player.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (player != null && prefs.getBoolean("music", true) && !player.isPlaying()) player.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        alive = false;
        if (player != null) {
            player.release();
            player = null;
        }
    }

    // ---- Tirada ciyaartoyda (SA-MP query) ----
    private void pollPlayers() {
        new Thread(() -> {
            while (alive) {
                String text;
                try {
                    text = queryPlayers();
                } catch (Exception e) {
                    text = "Server-ka lama gaari karo";
                }
                final String t = text;
                ui.post(() -> playersText.setText(t));
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }).start();
    }

    private String queryPlayers() throws Exception {
        String[] parts = Config.SERVER_IP.split("\\.");
        byte[] pkt = new byte[11];
        pkt[0] = 'S'; pkt[1] = 'A'; pkt[2] = 'M'; pkt[3] = 'P';
        for (int i = 0; i < 4; i++) pkt[4 + i] = (byte) Integer.parseInt(parts[i]);
        pkt[8] = (byte) (Config.SERVER_PORT & 0xFF);
        pkt[9] = (byte) ((Config.SERVER_PORT >> 8) & 0xFF);
        pkt[10] = 'i';
        DatagramSocket s = new DatagramSocket();
        try {
            s.setSoTimeout(3000);
            InetAddress addr = InetAddress.getByName(Config.SERVER_IP);
            s.send(new DatagramPacket(pkt, pkt.length, addr, Config.SERVER_PORT));
            byte[] buf = new byte[512];
            DatagramPacket r = new DatagramPacket(buf, buf.length);
            s.receive(r);
            int players = (buf[12] & 0xFF) | ((buf[13] & 0xFF) << 8);
            int max = (buf[14] & 0xFF) | ((buf[15] & 0xFF) << 8);
            return "Ciyaartoyda: " + players + " / " + max;
        } finally {
            s.close();
        }
    }
}
