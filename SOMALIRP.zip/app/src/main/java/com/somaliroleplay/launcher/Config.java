package com.somaliroleplay.launcher;

/** Wax kasta oo halkan ah ayaad bedeli kartaa. */
public class Config {
    // Server-ka
    public static final String SERVER_IP = "51.254.178.238";
    public static final int SERVER_PORT = 7777;

    // Linkiga faylasha ciyaarta (Update). Halkan geli linkigaaga.
    // Tusaale: "https://example.com/gamefiles.zip"
    public static final String GAME_FILES_URL = "";

    // Package-ka ciyaarta ee la furayo marka la riixo BILOW.
    public static final String GAME_PACKAGE = "com.rockstargames.gtasa";

    // Linkiyada bulshada
    public static final String DISCORD_URL = "https://discord.com";
    public static final String INSTAGRAM_URL = "https://instagram.com";
    public static final String WEBSITE_URL = "https://example.com";
    public static final String APP_URL = "https://example.com";
}
